package com.example.dlsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
