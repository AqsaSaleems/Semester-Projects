package Electricity;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.*;

public class GenerateBill extends JFrame implements ActionListener {
    // UI components
    JLabel meterLabel, monthLabel, unitsLabel;
    JTextField meterTextField, monthTextField, unitsTextField;
    JButton generateButton;
    JLabel logoLabel;

    public GenerateBill() {
         ImageIcon logoIcon = new ImageIcon(getClass().getResource("/Electricity/icons/generate.jpg"));
        Image logoImage = logoIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        ImageIcon scaledLogoIcon = new ImageIcon(logoImage);
        logoLabel = new JLabel(scaledLogoIcon);
        logoLabel.setBounds(420, 20, 200, 200);
        add(logoLabel);

//         ImageIcon logoIcon = new ImageIcon(getClass().getResource("/Electricity/icons/generate.jpg"));
////        l1 = new JLabel(logoIcon);
//         Image image = logoIcon.getImage().getScaledInstance(270, 270, Image.SCALE_DEFAULT);
//          ImageIcon img2 = new ImageIcon(image);
//
//        //j8=new JLabel(img2);
//        add(l1);

//        meterLabel = new JLabel("Meter Number");
        setTitle("Generate Bill");
        setBounds(400, 200, 800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(null);

        meterLabel = new JLabel("Meter Number");
        meterLabel.setBounds(100, 50, 120, 30);
        add(meterLabel);

        meterTextField = new JTextField();
        meterTextField.setBounds(240, 50, 150, 30);
        add(meterTextField);

        monthLabel = new JLabel("Month");
        monthLabel.setBounds(100, 100, 120, 30);
        add(monthLabel);

        monthTextField = new JTextField();
        monthTextField.setBounds(240, 100, 150, 30);
        add(monthTextField);

        unitsLabel = new JLabel("Units Consumed");
        unitsLabel.setBounds(100, 150, 120, 30);
        add(unitsLabel);

        unitsTextField = new JTextField();
        unitsTextField.setBounds(240, 150, 150, 30);
        add(unitsTextField);

        generateButton = new JButton("Generate Bill");
        generateButton.setBounds(240, 200, 150, 30);
        generateButton.addActionListener(this);
        add(generateButton);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == generateButton) {
            String meterNumber = meterTextField.getText();
            String month = monthTextField.getText();
            String units = unitsTextField.getText();

            // Calculate the bill amount
            double unitsConsumed = Double.parseDouble(units);
//            double billAmount = unitsConsumed * 5.0; // Assuming 5 rupees per unit
            double billAmount = (unitsConsumed*7) + 98 + 42 + 112+48;
            // Display the generated bill on the screen
            String billText = "Bill Details:\n" +
                    "Meter Number: " + meterNumber + "\n" +
                    "Month: " + month + "\n" +
                    "Units Consumed: " + unitsConsumed + "\n" +
                    "Bill Amount: " + billAmount;
            JOptionPane.showMessageDialog(null, billText);
        }
    }

    public static void main(String[] args) {
        new GenerateBill().setVisible(true);
    }
}
