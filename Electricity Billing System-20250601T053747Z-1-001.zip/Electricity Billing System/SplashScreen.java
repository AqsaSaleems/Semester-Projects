package Electricity;

import java.awt.*;
import javax.swing.*;

public class SplashScreen extends JWindow {

    public SplashScreen(int duration) {
        JPanel content = (JPanel) getContentPane();
        content.setBackground(Color.WHITE);

        // Set the splash screen image
        ImageIcon splashIcon = new ImageIcon(getClass().getResource("/Electricity/icons/loading.jpg"));
        JLabel splashLabel = new JLabel(splashIcon);
        content.add(splashLabel, BorderLayout.CENTER);

        // Set the size and position of the splash screen
        int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
        int splashWidth = splashIcon.getIconWidth();
        int splashHeight = splashIcon.getIconHeight();
        setLocation((screenWidth - splashWidth) / 2, (screenHeight - splashHeight) / 2);
        setSize(splashWidth, splashHeight);

        // Display the splash screen for the specified duration
        setVisible(true);
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        setVisible(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SplashScreen splashScreen = new SplashScreen(3000); // Set the duration in milliseconds
            splashScreen.showSplashScreen();
        });
    }

    public void showSplashScreen() {
        // Create the main frame
        JFrame frame = new JFrame("Electricity Billing System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set the content pane to be an instance of the homepage class
        homepage homePage = new homepage();
        frame.setContentPane(homePage);

        // Set the size and visibility of the frame
        frame.setSize(1600, 690);
        frame.setVisible(true);
    }
}
