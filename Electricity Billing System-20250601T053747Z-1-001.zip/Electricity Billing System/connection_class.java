package Electricity;
import java.sql.*;
public class connection_class {
        Connection cn;
        Statement stm;
        public connection_class(){
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/billing","root","hacked");
                stm=cn.createStatement();
                if(cn.isClosed()){
                    System.out.println("closed");
                }
                else{
                    System.out.println("success******");
                }
            }catch(Exception e){
                e.printStackTrace();
            }}
        public static void main(String s[]){
                new connection_class();
            }}
        

