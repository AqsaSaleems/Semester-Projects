import com.mycompany.metroroutetrackingapp2.MetroRouteTrackingApp2;
import javax.swing.*;
import java.awt.*;


public class FeaturesInterface extends JFrame {

    public FeaturesInterface() {
        setTitle("Metro Route Tracking System Features");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Features of Metro Route Tracking System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(titleLabel, BorderLayout.NORTH);

        // Features as a list in a JTextArea
        JTextArea featuresTextArea = new JTextArea();
        featuresTextArea.setEditable(false);
        featuresTextArea.setFont(new Font("Arial", Font.PLAIN, 16));

        String featureText = "Features:\n\n" +
                "1. List of Stations\n" +
                "2. Show Map\n" +
                "3. Shortest Distance\n" +
                "4. Depth-First Search\n" +
                "5. Heap Sort\n" +
                "6. Breadth-First Search\n";

        featuresTextArea.setText(featureText);
        featuresTextArea.setOpaque(false); // Make the text area transparent
        featuresTextArea.setAlignmentX(Component.CENTER_ALIGNMENT);
        featuresTextArea.setAlignmentY(Component.CENTER_ALIGNMENT);

        panel.add(featuresTextArea, BorderLayout.CENTER);

        // Button to jump to Metro Route Tracking interface
        JButton jumpButton = new JButton("Jump to Metro Route Tracking");
        jumpButton.addActionListener(e -> {
            MetroRouteTrackingApp2 metroApp = new MetroRouteTrackingApp2();
            metroApp.setVisible(true);
            dispose(); // Close the current interface after proceeding
        });
        panel.add(jumpButton, BorderLayout.SOUTH);

        add(panel);
    }
}
