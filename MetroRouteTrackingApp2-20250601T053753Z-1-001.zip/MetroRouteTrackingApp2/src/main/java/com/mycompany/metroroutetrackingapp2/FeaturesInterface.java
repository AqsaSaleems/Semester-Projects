package com.mycompany.metroroutetrackingapp2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FeaturesInterface extends JFrame {

    public FeaturesInterface() {
        setTitle("Metro Route Tracking System Features");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(255, 218, 185)); // Set background color to peach

        JLabel titleLabel = new JLabel("About the Application");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Panel for holding the text content with peach background
        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setBackground(new Color(255, 218, 185)); // Set peach background for text

        // Features with descriptions
        JTextPane featuresTextPane = new JTextPane();
        featuresTextPane.setEditable(false);
        featuresTextPane.setContentType("text/html");
        featuresTextPane.setFont(new Font("Arial", Font.PLAIN, 18));

        String featureText = "<html><body>" +
               "<h2>Features:</h2>" +
"<ul>" +
"<li><b><font size='+1'>List of Stations:</font></b> Display all metro stations.</li>" +
"<p>A feature that showcases a complete list of metro stations available in the system.</p>" +
"<li><b><font size='+1'>Show Map:</font></b> Visualize the metro route map.</li>" +
"<p>Provides a visual representation of the entire metro route map.</p>" +
"<li><b><font size='+1'>Shortest Distance:</font></b> Find the shortest distance between stations.</li>" +
"<p>Calculates and displays the shortest route distance between two metro stations.</p>" +
"<li><b><font size='+1'>Depth-First Search:</font></b> Perform a depth-first search algorithm.</li>" +
"<p>An algorithm to traverse the graph or network in a depthward motion.</p>" +
"<li><b><font size='+1'>Heap Sort:</font></b> Implement heap sort algorithm.</li>" +
"<p>A sorting technique to arrange data elements in an alphabetical order using minheap.</p>" +
"<li><b><font size='+1'>Breadth-First Search:</font></b> Execute a breadth-first search algorithm.</li>" +
"<p>An algorithm to traverse the graph or network in a breadthward motion.</p>" +
"<li><b><font size='+1'>Count Stops:</font></b> Calculate the number of stops from source to destination.</li>" +
"<p>Determines the total number of stops between the specified source and destination.</p>" +
"<li><b><font size='+1'>Distance Travel:</font></b> Calculate the distance traveled in kilometers.</li>" +
"<p>Estimates the total distance covered between the source and destination stations.</p>" +
"<li><b><font size='+1'>Time Travel:</font></b> Estimate the travel time in hours.</li>" +
"<p>Provides an approximate duration of travel between the source and destination stations.</p>" +
"</ul></body></html>";

        featuresTextPane.setText(featureText);
        textPanel.add(featuresTextPane, BorderLayout.CENTER);

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(textPanel, BorderLayout.CENTER);

     JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                welcome_page welcomePage = new welcome_page();
                welcomePage.setVisible(true);
                dispose(); 
                
            }
        });
        panel.add(backButton, BorderLayout.WEST);

        // Insert the image without any background color
       
        
          ImageIcon imageIcon = new ImageIcon("C:\\Users\\PMLS\\Desktop\\DSA Project\\bus image 1.jpg");
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setBounds(500, 50, 100, 100); // Set X, Y, width, and height for the image
        panel.add(imageLabel, BorderLayout.EAST);

        // Jump to Metro Route Tracking interface button
        JButton jumpButton = new JButton("Click to proceed to next");
        jumpButton.addActionListener(e -> {
            MetroRouteTrackingApp2 metroApp = new MetroRouteTrackingApp2();
            metroApp.setVisible(true);
            dispose(); // Close the current interface after proceeding
        });
        panel.add(jumpButton, BorderLayout.SOUTH);

        add(panel);
        
    }
}
