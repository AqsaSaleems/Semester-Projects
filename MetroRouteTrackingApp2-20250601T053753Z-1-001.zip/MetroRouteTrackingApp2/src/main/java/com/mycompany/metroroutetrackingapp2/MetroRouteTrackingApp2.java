package com.mycompany.metroroutetrackingapp2;


import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.awt.Image;
public class MetroRouteTrackingApp2 extends JFrame {
    private static final int INF = Integer.MAX_VALUE / 2;
    private List<String> stations;
    private List<List<Integer>> graph;
    private JButton countStopsButton; 
    private JTextArea outputTextArea;
    private JComboBox<String> sourceStationComboBox;
    private JComboBox<String> destinationStationComboBox;
    private JButton listStationsButton;
    private JButton showMapButton;
    private JButton shortestDistanceButton;
    private JButton depthFirstSearchButton;
    private JButton heapSortButton;
    private JButton breadthFirstSearchButton;
  private JButton calculateDistanceButton;
  private Map<String, double[]> stationCoordinates;
  private JButton calculateTimeButton;
private double averageSpeedKmPerHour = 15.0;

    public MetroRouteTrackingApp2() {
        setTitle("Metro Route Tracking App");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
           panel.setBackground(new Color(255, 218, 185)); // Set background color to peach
       
        outputTextArea = new JTextArea(20, 120);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        panel.add(scrollPane);
       outputTextArea.setText("\t\t\t\t\tWelcome to the Route Tracking App!");
outputTextArea.append("\n");
outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
outputTextArea.append("      " + "\uD83D\uDE86" + "    " + "METRO ROUTE TRACKING DETAILS" + "    " + "\uD83D\uDE86" + "     \n");
outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
outputTextArea.append("\n");
outputTextArea.append("Dear Passengers,\n\n");
outputTextArea.append("Welcome aboard our Metro Route Tracking App. Your journey with us is our utmost priority, and we aim to provide you with seamless travel experiences.\n\n");
outputTextArea.append("Navigate through our app's functionalities, including station listings, finding the shortest distance, and estimating travel time between stations.\n\n");
outputTextArea.append("We are delighted to have you on board and hope you have a comfortable and efficient journey.\n\n");
outputTextArea.append("If you have any queries or require assistance, our team is always available to serve you.\n\n");
outputTextArea.append("Wishing you a pleasant journey with us!\n");
outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
outputTextArea.append("\n");
outputTextArea.append("Best Regards,\n");
outputTextArea.append("[Amna & Aqsa] Management Team\n");

ImageIcon imageIcon = new ImageIcon("C:\\Users\\PMLS\\Desktop\\DSA Project\\Google-Maps.jpg");
Image image = imageIcon.getImage(); // Transform ImageIcon to Image
Image newImage = image.getScaledInstance(250, 250, java.awt.Image.SCALE_SMOOTH); // Resize the image

// Create a new ImageIcon from the scaled image
ImageIcon newImageIcon = new ImageIcon(newImage);
JLabel imageLabel = new JLabel(newImageIcon);
panel.add(imageLabel, BorderLayout.WEST); 

        sourceStationComboBox = new JComboBox<>();
        destinationStationComboBox = new JComboBox<>();
        panel.add(sourceStationComboBox);
        panel.add(destinationStationComboBox);

        // Populate the stationComboBoxes
        initializeData(); // Initialize stations and connections

        listStationsButton = new JButton("List Stations");
        panel.add(listStationsButton);

        showMapButton = new JButton("Show Map");
        panel.add(showMapButton);

        shortestDistanceButton = new JButton("Shortest Distance");
        panel.add(shortestDistanceButton);

        depthFirstSearchButton = new JButton("Depth-First Search");
        panel.add(depthFirstSearchButton);
        countStopsButton = new JButton("Count Stops");
        panel.add(countStopsButton);
countStopsButton.addActionListener(this::countStopsBetween);

        add(panel);
        heapSortButton = new JButton("Heap Sort");
        panel.add(heapSortButton);

        breadthFirstSearchButton = new JButton("Breadth-First Search");
        panel.add(breadthFirstSearchButton);

        add(panel);
        
          calculateDistanceButton = new JButton("Calculate Distance");
    panel.add(calculateDistanceButton);

    // ActionListener for calculateDistanceButton
    calculateDistanceButton.addActionListener(this::calculateDistanceBetween);

    // Initialize the station coordinates
    initializeStationCoordinates();

    add(panel);
   calculateTimeButton = new JButton("Calculate Time");
    panel.add(calculateTimeButton);

    // ActionListener for calculateTimeButton
    calculateTimeButton.addActionListener(this::calculateTimeRequired);
       add(panel);

    // Add the bus stops to the combo boxes
    for (String station : stations) {
        sourceStationComboBox.addItem(station);
        destinationStationComboBox.addItem(station);
    }

        // ActionListener for listStationsButton, showMapButton, shortestDistanceButton, depthFirstSearchButton, heapSortButton
        listStationsButton.addActionListener(this::listStations);
        showMapButton.addActionListener(this::showMap);
        shortestDistanceButton.addActionListener(this::findShortestDistance);
        depthFirstSearchButton.addActionListener(this::performDFS);
        heapSortButton.addActionListener(this::performHeapSort);

        // ActionListener for breadthFirstSearchButton
        breadthFirstSearchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performBFS();
            }

       private void performBFS() {
    String srcStation = (String) sourceStationComboBox.getSelectedItem();
    String destStation = (String) destinationStationComboBox.getSelectedItem();

    int srcIndex = stations.indexOf(srcStation);
    int destIndex = stations.indexOf(destStation);

    // Perform BFS to find the shortest path
    List<String> shortestPath = bfs(srcIndex, destIndex);

    if (shortestPath != null) {
        StringBuilder output = new StringBuilder();
        output.append("\nPerforming Breadth-First Search (BFS):\n");
        output.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        output.append("Dear Passengers,\n\n");
        output.append("We are performing a Breadth-First Search (BFS) to explore the path between selected stations.\n");
        output.append("Please wait for the results.\n\n");
        output.append("Thank you for your patience!\n");
        output.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n");

        output.append("By Applying Breath First Search Shortest path from ").append(srcStation).append(" to ").append(destStation).append(":\n");
        output.append("Path: ").append(String.join(" -> ", shortestPath));

        outputTextArea.setText(output.toString());
    } else {
        outputTextArea.setText("No path found from " + srcStation + " to " + destStation);
    }
}

        });
    }

     private void initializeData() {
     // Existing stations
    stations = new ArrayList<>();
    stations.add("Tower");
    stations.add("Nipa");
    stations.add("Gulshan");
    stations.add("Saddar");
    stations.add("Clifton");
    stations.add("Airport");
    stations.add("Liaquatabad");
    stations.add("Korangi");
    stations.add("Landhi");
    stations.add("Malir");
    stations.add("Shahra-e-Faisal");
    stations.add("Orangi Town");
    stations.add("North Nazimabad");
    stations.add("Gulistan-e-Johar");
    stations.add("Nazimabad");

    // connections 
    graph = new ArrayList<>();
    graph.add(List.of(1, 2)); // Tower connections
    graph.add(List.of(0, 3, 4)); // Nipa connections
    graph.add(List.of(0, 4)); // Gulshan connections
    graph.add(List.of(1, 5)); // Saddar connections
    graph.add(List.of(1, 2, 5)); // Clifton connections
    graph.add(List.of(3, 4)); // Airport connections
    graph.add(List.of(0, 7)); // Liaquatabad connections
    graph.add(List.of(2, 8)); // Korangi connections
    graph.add(List.of(3, 9)); // Landhi connections
    graph.add(List.of(4, 10)); // Malir connections
    graph.add(List.of(5, 11)); // Shahra-e-Faisal connections
    graph.add(List.of(6, 12)); // Orangi Town connections
    graph.add(List.of(7, 13)); // North Nazimabad connections
    graph.add(List.of(8, 14)); // Gulistan-e-Johar connections
    graph.add(List.of(9)); // Nazimabad connections

    // Add the new stations to the combo boxes
    for (String station : stations) {
        sourceStationComboBox.addItem(station);
        destinationStationComboBox.addItem(station);
    }
     }
    private void listStations(ActionEvent e) {
    outputTextArea.setText("");

    StringBuilder stationList = new StringBuilder("List of Metro Bus Stops:\n");
    stationList.append("Our Metro Bus route covers a total of ").append(stations.size()).append(" areas.\n\n");

    for (int i = 0; i < stations.size(); i++) {
        stationList.append(i + 1).append(". ").append(stations.get(i)).append("\n");
    }

    outputTextArea.setText(stationList.toString());
}
 private void showMap(ActionEvent e) {
    outputTextArea.setText("");
 outputTextArea.append("Displaying Metro Bus Route Map:\n");
    outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
    outputTextArea.append("Dear Passengers,\n\n");
    outputTextArea.append("Here is the visual representation of our Metro Bus route.\n");
    outputTextArea.append("You can explore the connections between different stations on the map.\n\n");
    outputTextArea.append("Enjoy your journey with us!\n");
    outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < graph.size(); i++) {
        StringBuilder connections = new StringBuilder();
        connections.append(stations.get(i)).append(" -> ");

        List<Integer> connectedStations = graph.get(i);
        if (connectedStations.isEmpty()) {
            connections.append("No connections");
        } else {
            for (int destination : connectedStations) {
                connections.append(stations.get(destination)).append(", ");
            }
            connections.setLength(connections.length() - 2); // Remove the extra comma and space at the end
        }
        
        connections.append("\n");
        outputTextArea.append(connections.toString());
    }

}
   private List<String> bfs(int src, int dest) {
    boolean[] visited = new boolean[stations.size()];
    int[] distance = new int[stations.size()];
    int[] parent = new int[stations.size()];

    Queue<Integer> queue = new LinkedList<>();
    queue.add(src);
    visited[src] = true;
    distance[src] = 0;
    parent[src] = -1;

    while (!queue.isEmpty()) {
        int current = queue.poll();

        if (current == dest) {
            // Reconstruct path
            List<String> path = new ArrayList<>();
            int crawl = dest;
            while (crawl != -1) {
                path.add(stations.get(crawl));
                crawl = parent[crawl];
            }
            Collections.reverse(path);
            return path;
        }

        for (int neighbor : graph.get(current)) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                distance[neighbor] = distance[current] + 1;
                parent[neighbor] = current;
                queue.add(neighbor);
            }
        }
    }
    return null; // No path found
}

    

 private void findShortestDistance(ActionEvent e) {
    String srcStation = (String) sourceStationComboBox.getSelectedItem();
    String destStation = (String) destinationStationComboBox.getSelectedItem();

    int srcIndex = stations.indexOf(srcStation);
    int destIndex = stations.indexOf(destStation);

    // Perform BFS to find the shortest path
    List<String> shortestPath = bfs(srcIndex, destIndex);

    if (shortestPath != null) {
        outputTextArea.setText(""); // Clearing the text area before appending new content
        outputTextArea.append("\nFinding Shortest Distance:\n");
        outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        outputTextArea.append("Dear Passengers,\n\n");
        outputTextArea.append("We are finding the shortest distance between selected stations.\n");
        outputTextArea.append("Please wait for the results.\n\n");
        outputTextArea.append("Thank you for your patience!\n");
        outputTextArea.append("\"---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n");

        outputTextArea.append("Shortest path from " + srcStation + " to " + destStation + ":\n");
        outputTextArea.append("Path: " + String.join(" -> ", shortestPath));
    } else {
        outputTextArea.setText("No path found from " + srcStation + " to " + destStation);
    }
}
private void performDFS(ActionEvent e) {
    boolean[] visited = new boolean[stations.size()];

    outputTextArea.setText("Performing Depth-First Search (DFS):\n");
    outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
    outputTextArea.append("Dear Passengers,\n\n");
    outputTextArea.append("We are performing a Depth-First Search (DFS) to traverse the stations.\n");
    outputTextArea.append("Please wait for the results.\n\n");
    outputTextArea.append("Thank you for your patience!\n");
    outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n");

    outputTextArea.append("DFS Traversal initiates from 'Tower' and 'Liaquatabad' because these stations are the starting points in our network.\n\n");

    for (int i = 0; i < stations.size(); i++) {
        if (!visited[i]) {
            outputTextArea.append("DFS Traversal from " + stations.get(i) + ":\n");
            depthFirstSearch(i, visited);
            outputTextArea.append("\n");
        }
    }
}

private void depthFirstSearch(int source, boolean[] visited) {
    visited[source] = true;
    outputTextArea.append(stations.get(source) + " "); // Append the station being visited

    for (int destination : graph.get(source)) {
        if (!visited[destination]) {
            depthFirstSearch(destination, visited);
        }
    }
}

private void performHeapSort(ActionEvent e) {
    heapSort(stations);

    outputTextArea.setText("Stations sorted by names using Heap Sort:\n");
    for (String station : stations) {
        outputTextArea.append(station + "\n"); // Append each station in sorted order
    }
}

    // Heap Sort Algorithm
    private void heapSort(List<String> arr) {
        int n = arr.size();

        // Build heap (rearrange array)
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
        }

        // One by one extract an element from heap
        for (int i = n - 1; i > 0; i--) {
            // Move current root to end
            String temp = arr.get(0);
            arr.set(0, arr.get(i));
            arr.set(i, temp);

            // call max heapify on the reduced heap
            heapify(arr, i, 0);
        }
    }

    // To heapify a subtree rooted with node i which is an index in arr[]
    private void heapify(List<String> arr, int n, int i) {
        int largest = i; // Initialize largest as root
        int l = 2 * i + 1; // left = 2*i + 1
        int r = 2 * i + 2; // right = 2*i + 2

        // If left child is larger than root
        if (l < n && arr.get(l).compareTo(arr.get(largest)) > 0) {
            largest = l;
        }

        // If right child is larger than largest so far
        if (r < n && arr.get(r).compareTo(arr.get(largest)) > 0) {
            largest = r;
        }

        // If largest is not root
        if (largest != i) {
            String swap = arr.get(i);
            arr.set(i, arr.get(largest));
            arr.set(largest, swap);

            // Recursively heapify the affected sub-tree
            heapify(arr, n, largest);
        }
    }
private void initializeStationCoordinates() {
    stationCoordinates = new HashMap<>();

    // Replace the placeholder coordinates with the actual coordinates
    stationCoordinates.put("Tower", new double[]{25.0700, 67.2848}); // Tower coordinates
    stationCoordinates.put("Nipa", new double[]{24.9208, 67.1188}); // Nipa coordinates
    stationCoordinates.put("Gulshan", new double[]{24.9293, 67.0896}); // Gulshan coordinates
    stationCoordinates.put("Saddar", new double[]{24.8607, 67.0011}); // Saddar coordinates
    stationCoordinates.put("Clifton", new double[]{24.8196, 67.0404}); // Clifton coordinates
    stationCoordinates.put("Airport", new double[]{24.9000, 67.1683}); // Airport coordinates
  stationCoordinates.put("Liaquatabad", new double[]{25.0700, 67.0423}); // Liaquatabad coordinates
    stationCoordinates.put("Korangi", new double[]{24.8394, 67.0346}); // Korangi coordinates
    stationCoordinates.put("Landhi", new double[]{24.8817, 67.1815}); // Landhi coordinates
    stationCoordinates.put("Malir", new double[]{24.8934, 67.1968}); // Malir coordinates
    stationCoordinates.put("Shahra-e-Faisal", new double[]{24.8805, 67.0690}); // Shahra-e-Faisal coordinates
    stationCoordinates.put("Orangi Town", new double[]{24.9586, 66.9911}); // Orangi Town coordinates
    stationCoordinates.put("North Nazimabad", new double[]{24.9395, 67.0206}); // North Nazimabad coordinates
    stationCoordinates.put("Gulistan-e-Johar", new double[]{24.9232, 67.0993}); // Gulistan-e-Johar coordinates
    stationCoordinates.put("Nazimabad", new double[]{24.9173, 67.0311}); // Nazimabad coordinates
}

private void calculateDistanceBetween(ActionEvent e) {
    String srcStation = (String) sourceStationComboBox.getSelectedItem();
    String destStation = (String) destinationStationComboBox.getSelectedItem();

    // Retrieve coordinates of source and destination stations
    double[] srcCoords = stationCoordinates.get(srcStation);
    double[] destCoords = stationCoordinates.get(destStation);

    if (srcCoords != null && destCoords != null) {
        // Calculate distance
        double distance = calculateDistanceInKm(srcCoords, destCoords);

        // Clear the outputTextArea before appending new content
        outputTextArea.setText("");

        outputTextArea.append("\nCalculating Distance between Stations:\n");
        outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        outputTextArea.append("Dear Passengers,\n\n");
        outputTextArea.append("We are calculating the distance between selected stations.\n");
        outputTextArea.append("Please wait for the results.\n\n");
        outputTextArea.append("Thank you for your patience!\n");
        outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

        outputTextArea.append("Distance between " + srcStation + " and " + destStation + ": " + distance + " km");
    } else {
        outputTextArea.setText("Coordinates not found for selected stations");
    }
}

// Method to calculate distance 
private double calculateDistanceInKm(double[] srcCoords, double[] destCoords) {
    final int R = 6371; // Earth's radius in kilometers
    double lat1 = Math.toRadians(srcCoords[0]);
    double lon1 = Math.toRadians(srcCoords[1]);
    double lat2 = Math.toRadians(destCoords[0]);
    double lon2 = Math.toRadians(destCoords[1]);

    double dlon = lon2 - lon1;
    double dlat = lat2 - lat1;

    double a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(dlon / 2), 2);
    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    double distance = R * c; // Distance in kilometers
    return Double.parseDouble(String.format("%.2f", distance)); // Return formatted distance with 2 decimal places
}

private void countStopsBetween(ActionEvent e) {
    String srcStation = (String) sourceStationComboBox.getSelectedItem();
    String destStation = (String) destinationStationComboBox.getSelectedItem();

    int srcIndex = stations.indexOf(srcStation);
    int destIndex = stations.indexOf(destStation);

    // Perform BFS to find the shortest path
    List<String> shortestPath = bfs(srcIndex, destIndex);

    if (shortestPath != null) {
        outputTextArea.setText(""); // Clearing the text area before appending new content
        outputTextArea.append("\nCounting Stops between Stations:\n");
        outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
        outputTextArea.append("Dear Passengers,\n\n");
        outputTextArea.append("We are counting the stops between selected stations.\n");
        outputTextArea.append("Please wait for the results.\n\n");
        outputTextArea.append("Thank you for your patience!\n");
        outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\\n\n");

        int numStops = shortestPath.size() - 1; // Number of stops is the number of vertices - 1
        outputTextArea.append("Number of Stops: " + numStops);
    } else {
        outputTextArea.setText("No path found from " + srcStation + " to " + destStation);
    }
}
private void calculateTimeRequired(ActionEvent e) {
    String srcStation = (String) sourceStationComboBox.getSelectedItem();
    String destStation = (String) destinationStationComboBox.getSelectedItem();

    // Clear the outputTextArea before appending new content
    outputTextArea.setText("");

    // Retrieve coordinates of source and destination stations
    double[] srcCoords = stationCoordinates.get(srcStation);
    double[] destCoords = stationCoordinates.get(destStation);

    if (srcCoords != null && destCoords != null) {
        // Calculate distance
        double distance = calculateDistanceInKm(srcCoords, destCoords);

        // Calculate time based on average speed
        double timeInHours = distance / averageSpeedKmPerHour;
        double timeInMinutes = timeInHours * 360; // Convert hours to minutes

        outputTextArea.append("\nCalculating Time Required:\n");
        outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n");
        outputTextArea.append("Dear Passengers,\n\n");
        outputTextArea.append("We are calculating the time required to travel between selected stations.\n");
        outputTextArea.append("Please wait for the results.\n\n");
        outputTextArea.append("Thank you for your patience!\n");
        outputTextArea.append("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n");

        outputTextArea.append("Time required to travel between " + srcStation + " and " + destStation + ": " + timeInMinutes + " minutes");
    } else {
        outputTextArea.setText("Coordinates not found for selected stations");
    }
}


  public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
        // Display the welcome page first
        welcome_page welcomePage = new welcome_page();
        welcomePage.setVisible(true);

        // After the welcome page is closed, display the feature interface
        welcomePage.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                FeaturesInterface featuresInterface = new FeaturesInterface();
                featuresInterface.setVisible(true);

                // After the feature interface is closed, display the Metro Route Tracking app
                featuresInterface.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                        MetroRouteTrackingApp2 metroApp = new MetroRouteTrackingApp2();
                        metroApp.setVisible(true);
                    }
                });
            }
        });
    });
  }
}

    




