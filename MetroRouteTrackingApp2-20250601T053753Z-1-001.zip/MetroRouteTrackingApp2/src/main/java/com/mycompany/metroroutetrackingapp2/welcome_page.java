package com.mycompany.metroroutetrackingapp2;

import javax.swing.*;
import java.awt.*;

public class welcome_page extends JFrame {

    public welcome_page() {
        setTitle("Welcome to Metro Route Tracking System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(255, 218, 185)); // Set background color to peach (RGB: 255, 218, 185)

        // Welcome message
       JLabel welcomeLabel = new JLabel("Welcome to Metro Route APP\n");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 32)); // Increase font size of welcome text
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        welcomeLabel.setBounds(400, 80, 500, 50); // Set X, Y, width, and height of the text
        panel.add(welcomeLabel);

        // Image (Resized to 350x250)
        ImageIcon imageIcon = new ImageIcon("C:\\Users\\PMLS\\Desktop\\DSA Project\\map.jpg");
        Image image = imageIcon.getImage();
        Image newImage = image.getScaledInstance(500, 350, Image.SCALE_SMOOTH);
        ImageIcon newImageIcon = new ImageIcon(newImage);
        JLabel imageLabel = new JLabel(newImageIcon);
        panel.add(imageLabel, BorderLayout.CENTER); // Place the resized image in the center

        // Button to proceed
        JButton proceedButton = new JButton("Click to Proceed Next");
        proceedButton.setPreferredSize(new Dimension(300, 60)); // Increase button size
        proceedButton.setBackground(new Color(139, 69, 19)); // Set background color to brown (RGB: 139, 69, 19)
        proceedButton.setForeground(Color.WHITE); // Set text color to white
        Font buttonFont = new Font("Arial", Font.BOLD, 18); // Increase font size of the button text
        proceedButton.setFont(buttonFont);
        proceedButton.addActionListener(e -> {
            FeaturesInterface app = new FeaturesInterface();
            app.setVisible(true);
            dispose(); // Close the welcome page after proceeding
        });
        panel.add(proceedButton, BorderLayout.SOUTH);

        add(panel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            welcome_page welcomePage = new welcome_page();
            welcomePage.setVisible(true);
        });
    }
}
