﻿
namespace tic_tac_toe_advanced
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnTic1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btntic2 = new System.Windows.Forms.Button();
            this.btntic5 = new System.Windows.Forms.Button();
            this.btntic3 = new System.Windows.Forms.Button();
            this.btntic4 = new System.Windows.Forms.Button();
            this.btntic6 = new System.Windows.Forms.Button();
            this.btntic7 = new System.Windows.Forms.Button();
            this.btntic9 = new System.Windows.Forms.Button();
            this.btntic8 = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.newgame = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblPlayerO = new System.Windows.Forms.Label();
            this.lblPlayerX = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1235, 65);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(77, 101);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1104, 581);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.btntic8);
            this.panel3.Controls.Add(this.btntic9);
            this.panel3.Controls.Add(this.btntic7);
            this.panel3.Controls.Add(this.btntic6);
            this.panel3.Controls.Add(this.btntic4);
            this.panel3.Controls.Add(this.btntic3);
            this.panel3.Controls.Add(this.btntic5);
            this.panel3.Controls.Add(this.btntic2);
            this.panel3.Controls.Add(this.btnTic1);
            this.panel3.Location = new System.Drawing.Point(11, 14);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(629, 539);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(646, 14);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(432, 539);
            this.panel4.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.lblPlayerO);
            this.panel5.Controls.Add(this.lblPlayerX);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Location = new System.Drawing.Point(20, 17);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(387, 169);
            this.panel5.TabIndex = 4;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.newgame);
            this.panel6.Controls.Add(this.exit);
            this.panel6.Controls.Add(this.reset);
            this.panel6.Location = new System.Drawing.Point(20, 210);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(387, 289);
            this.panel6.TabIndex = 5;
            // 
            // btnTic1
            // 
            this.btnTic1.BackColor = System.Drawing.Color.Silver;
            this.btnTic1.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTic1.Location = new System.Drawing.Point(3, 17);
            this.btnTic1.Name = "btnTic1";
            this.btnTic1.Size = new System.Drawing.Size(200, 158);
            this.btnTic1.TabIndex = 0;
            this.btnTic1.UseVisualStyleBackColor = false;
            this.btnTic1.Click += new System.EventHandler(this.btnTic1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(411, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 55);
            this.label1.TabIndex = 1;
            this.label1.Text = "Tic Tac Toe";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btntic2
            // 
            this.btntic2.BackColor = System.Drawing.Color.Silver;
            this.btntic2.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntic2.Location = new System.Drawing.Point(209, 17);
            this.btntic2.Name = "btntic2";
            this.btntic2.Size = new System.Drawing.Size(200, 158);
            this.btntic2.TabIndex = 1;
            this.btntic2.UseVisualStyleBackColor = false;
            this.btntic2.Click += new System.EventHandler(this.btntic2_Click);
            // 
            // btntic5
            // 
            this.btntic5.BackColor = System.Drawing.Color.Silver;
            this.btntic5.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntic5.Location = new System.Drawing.Point(209, 187);
            this.btntic5.Name = "btntic5";
            this.btntic5.Size = new System.Drawing.Size(200, 158);
            this.btntic5.TabIndex = 2;
            this.btntic5.UseVisualStyleBackColor = false;
            this.btntic5.Click += new System.EventHandler(this.btntic5_Click);
            // 
            // btntic3
            // 
            this.btntic3.BackColor = System.Drawing.Color.Silver;
            this.btntic3.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntic3.Location = new System.Drawing.Point(415, 17);
            this.btntic3.Name = "btntic3";
            this.btntic3.Size = new System.Drawing.Size(200, 158);
            this.btntic3.TabIndex = 3;
            this.btntic3.UseVisualStyleBackColor = false;
            this.btntic3.Click += new System.EventHandler(this.btntic3_Click);
            // 
            // btntic4
            // 
            this.btntic4.BackColor = System.Drawing.Color.Silver;
            this.btntic4.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntic4.Location = new System.Drawing.Point(3, 187);
            this.btntic4.Name = "btntic4";
            this.btntic4.Size = new System.Drawing.Size(200, 158);
            this.btntic4.TabIndex = 4;
            this.btntic4.UseVisualStyleBackColor = false;
            this.btntic4.Click += new System.EventHandler(this.btntic4_Click);
            // 
            // btntic6
            // 
            this.btntic6.BackColor = System.Drawing.Color.Silver;
            this.btntic6.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntic6.Location = new System.Drawing.Point(415, 187);
            this.btntic6.Name = "btntic6";
            this.btntic6.Size = new System.Drawing.Size(200, 158);
            this.btntic6.TabIndex = 5;
            this.btntic6.UseVisualStyleBackColor = false;
            this.btntic6.Click += new System.EventHandler(this.btntic6_Click);
            // 
            // btntic7
            // 
            this.btntic7.BackColor = System.Drawing.Color.Silver;
            this.btntic7.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntic7.Location = new System.Drawing.Point(3, 361);
            this.btntic7.Name = "btntic7";
            this.btntic7.Size = new System.Drawing.Size(200, 158);
            this.btntic7.TabIndex = 6;
            this.btntic7.UseVisualStyleBackColor = false;
            this.btntic7.Click += new System.EventHandler(this.btntic7_Click);
            // 
            // btntic9
            // 
            this.btntic9.BackColor = System.Drawing.Color.Silver;
            this.btntic9.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntic9.Location = new System.Drawing.Point(415, 361);
            this.btntic9.Name = "btntic9";
            this.btntic9.Size = new System.Drawing.Size(200, 158);
            this.btntic9.TabIndex = 7;
            this.btntic9.UseVisualStyleBackColor = false;
            this.btntic9.Click += new System.EventHandler(this.btntic9_Click);
            // 
            // btntic8
            // 
            this.btntic8.BackColor = System.Drawing.Color.Silver;
            this.btntic8.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntic8.Location = new System.Drawing.Point(209, 361);
            this.btntic8.Name = "btntic8";
            this.btntic8.Size = new System.Drawing.Size(200, 158);
            this.btntic8.TabIndex = 8;
            this.btntic8.UseVisualStyleBackColor = false;
            this.btntic8.Click += new System.EventHandler(this.btntic8_Click);
            // 
            // reset
            // 
            this.reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reset.Location = new System.Drawing.Point(21, 162);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(165, 82);
            this.reset.TabIndex = 8;
            this.reset.Text = "Reset";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // exit
            // 
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.Location = new System.Drawing.Point(192, 162);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(175, 82);
            this.exit.TabIndex = 9;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // newgame
            // 
            this.newgame.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newgame.Location = new System.Drawing.Point(21, 13);
            this.newgame.Name = "newgame";
            this.newgame.Size = new System.Drawing.Size(346, 82);
            this.newgame.TabIndex = 10;
            this.newgame.Text = "New Game";
            this.newgame.UseVisualStyleBackColor = true;
            this.newgame.Click += new System.EventHandler(this.button12_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 33);
            this.label2.TabIndex = 0;
            this.label2.Text = "Player X";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 33);
            this.label3.TabIndex = 1;
            this.label3.Text = "Player O";
            // 
            // lblPlayerO
            // 
            this.lblPlayerO.BackColor = System.Drawing.Color.Silver;
            this.lblPlayerO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPlayerO.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerO.Location = new System.Drawing.Point(163, 77);
            this.lblPlayerO.Name = "lblPlayerO";
            this.lblPlayerO.Size = new System.Drawing.Size(137, 33);
            this.lblPlayerO.TabIndex = 3;
            this.lblPlayerO.Text = "0";
            this.lblPlayerO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblPlayerX
            // 
            this.lblPlayerX.BackColor = System.Drawing.Color.Silver;
            this.lblPlayerX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPlayerX.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerX.Location = new System.Drawing.Point(163, 22);
            this.lblPlayerX.Name = "lblPlayerX";
            this.lblPlayerX.Size = new System.Drawing.Size(133, 33);
            this.lblPlayerX.TabIndex = 2;
            this.lblPlayerX.Text = "0";
            this.lblPlayerX.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnTic1;
        private System.Windows.Forms.Button newgame;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Button btntic8;
        private System.Windows.Forms.Button btntic9;
        private System.Windows.Forms.Button btntic7;
        private System.Windows.Forms.Button btntic6;
        private System.Windows.Forms.Button btntic4;
        private System.Windows.Forms.Button btntic3;
        private System.Windows.Forms.Button btntic5;
        private System.Windows.Forms.Button btntic2;
        private System.Windows.Forms.Label lblPlayerO;
        private System.Windows.Forms.Label lblPlayerX;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}

