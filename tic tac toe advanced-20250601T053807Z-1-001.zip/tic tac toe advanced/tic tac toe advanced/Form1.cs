﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tic_tac_toe_advanced
{
    public partial class Form1 : Form
    {Boolean checker;
        int plusone;
        void Enable_False()
        {
            btnTic1.Enabled = false;

            btntic2.Enabled = false;

            btntic3.Enabled = false;

            btntic4.Enabled = false;

            btntic5.Enabled = false;

            btntic6.Enabled = false;

            btntic7.Enabled = false;

            btntic8.Enabled = false;

            btntic9.Enabled = false;

        }
        void score()
        {
            if(btnTic1.Text=="X"&& btntic2.Text == "X"&& btntic3.Text == "X")
            {
                btnTic1.BackColor = System.Drawing.Color.PowderBlue;
                btntic2.BackColor = System.Drawing.Color.PowderBlue;
                btntic3.BackColor = System.Drawing.Color.PowderBlue;
                MessageBox.Show("The winner is player X", "Toc tac Toe",MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerX.Text);
                lblPlayerX.Text = Convert.ToString(plusone+1);
                Enable_False();
            }

            if (btnTic1.Text == "X" && btntic4.Text == "X" && btntic7.Text == "X")
            {
                btnTic1.BackColor = System.Drawing.Color.Pink;
                btntic4.BackColor = System.Drawing.Color.Pink;
                btntic7.BackColor = System.Drawing.Color.Pink;
                MessageBox.Show("The winner is player X", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerX.Text);
                lblPlayerX.Text = Convert.ToString(plusone+1);
                Enable_False();
            }

            if (btnTic1.Text == "X" && btntic5.Text == "X" && btntic9.Text == "X")
            {
                btnTic1.BackColor = System.Drawing.Color.Crimson;
                btntic5.BackColor = System.Drawing.Color.Crimson;
                btntic9.BackColor = System.Drawing.Color.Crimson;
                MessageBox.Show("The winner is player X", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerX.Text);
                lblPlayerX.Text = Convert.ToString(plusone+1);
                Enable_False();
            }
            if (btntic3.Text == "X" && btntic5.Text == "X" && btntic7.Text == "X")
            {
                btntic3.BackColor = System.Drawing.Color.CadetBlue;
                btntic5.BackColor = System.Drawing.Color.CadetBlue;
                btntic7.BackColor = System.Drawing.Color.CadetBlue;
                MessageBox.Show("The winner is player X", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerX.Text);
                lblPlayerX.Text = Convert.ToString(plusone+1);
                Enable_False();
            }

            if (btntic2.Text == "X" && btntic5.Text == "X" && btntic8.Text == "X")
            {
                btntic2.BackColor = System.Drawing.Color.SlateBlue;
                btntic5.BackColor = System.Drawing.Color.SlateBlue;
                btntic8.BackColor = System.Drawing.Color.SlateBlue;
                MessageBox.Show("The winner is player X", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerX.Text);
                lblPlayerX.Text = Convert.ToString(plusone+1);
                Enable_False();
            }
            if (btntic3.Text == "X" && btntic6.Text == "X" && btntic9.Text == "X")
            {
                btntic3.BackColor = System.Drawing.Color.Violet;
                btntic6.BackColor = System.Drawing.Color.Violet;
                btntic9.BackColor = System.Drawing.Color.Violet;
                MessageBox.Show("The winner is player X", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerX.Text);
                lblPlayerX.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btntic4.Text == "X" && btntic5.Text == "X" && btntic6.Text == "X")
            {
                btntic4.BackColor = System.Drawing.Color.DarkBlue;
                btntic5.BackColor = System.Drawing.Color.DarkBlue;
                btntic6.BackColor =System.Drawing. Color.DarkBlue;
                MessageBox.Show("The winner is player X", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerX.Text);
                lblPlayerX.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btntic7.Text == "X" && btntic8.Text == "X" && btntic9.Text == "X")
            {
                btntic7.BackColor = System.Drawing.Color.Azure;
                btntic8.BackColor = System.Drawing.Color.Azure;
                btntic9.BackColor = System.Drawing.Color.Azure;
                MessageBox.Show("The winner is player X", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerX.Text);
                lblPlayerX.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            //---------------------------------------------
            if (btnTic1.Text == "O" && btntic2.Text == "O" && btntic3.Text == "O")
            {
                btnTic1.BackColor = System.Drawing.Color.AliceBlue;
                btntic2.BackColor = System.Drawing.Color.AliceBlue;
                btntic3.BackColor = System.Drawing.Color.AliceBlue;
                MessageBox.Show("The winner is player O", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerO.Text);
                lblPlayerO.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btnTic1.Text == "O" && btntic4.Text == "O" && btntic7.Text == "O")
            {
                btnTic1.BackColor = System.Drawing.Color.LemonChiffon;
                btntic4.BackColor = System.Drawing.Color.LemonChiffon;
                btntic7.BackColor = System.Drawing.Color.LemonChiffon;
                MessageBox.Show("The winner is player O", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerO.Text);
                lblPlayerO.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btnTic1.Text == "O" && btntic5.Text == "O" && btntic9.Text == "O")
            {
                btnTic1.BackColor = System.Drawing.Color.BlueViolet;
                btntic5.BackColor = System.Drawing.Color.BlueViolet;
                btntic9.BackColor = System.Drawing.Color.BlueViolet;
                MessageBox.Show("The winner is player O", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerO.Text);
                lblPlayerO.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btntic3.Text == "O" && btntic5.Text == "O" && btntic7.Text == "O")
            {
                btntic3.BackColor = System.Drawing.Color.NavajoWhite;
                btntic5.BackColor = System.Drawing.Color.NavajoWhite;
                btntic7.BackColor = System.Drawing.Color.NavajoWhite;
                MessageBox.Show("The winner is player O", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerO.Text);
                lblPlayerO.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btntic2.Text == "O" && btntic5.Text == "O" && btntic8.Text == "O")
            {
                btntic2.BackColor = System.Drawing.Color.SandyBrown;
                btntic5.BackColor = System.Drawing.Color.SandyBrown;
                btntic8.BackColor = System.Drawing.Color.SandyBrown;
                MessageBox.Show("The winner is player O", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerO.Text);
                lblPlayerO.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btntic3.Text == "O" && btntic6.Text == "O" && btntic9.Text == "O")
            {
                btntic3.BackColor = System.Drawing.Color.SeaGreen;
                btntic6.BackColor = System.Drawing.Color.SeaGreen;
                btntic9.BackColor = System.Drawing.Color.SeaGreen;
                MessageBox.Show("The winner is player O", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerO.Text);
                lblPlayerO.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btntic4.Text == "O" && btntic5.Text == "O" && btntic6.Text == "O")
            {
                btntic4.BackColor = System.Drawing.Color.Azure;
                btntic5.BackColor = System.Drawing.Color.Azure;
                btntic6.BackColor = System.Drawing.Color.Azure;
                MessageBox.Show("The winner is player O", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerO.Text);
                lblPlayerO.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }
            if (btntic7.Text == "O" && btntic8.Text == "O" && btntic9.Text == "O")
            {
                btntic7.BackColor = System.Drawing.Color.Azure;
                btntic8.BackColor = System.Drawing.Color.Azure;
                btntic9.BackColor = System.Drawing.Color.Azure;
                MessageBox.Show("The winner is player O", "Toc tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                plusone = int.Parse(lblPlayerO.Text);
                lblPlayerO.Text = Convert.ToString(plusone + 1);
                Enable_False();
            }


        }
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            try
            {
                btnTic1.Enabled = true;

                btntic2.Enabled = true;

                btntic3.Enabled = true;

                btntic4.Enabled = true;

                btntic5.Enabled = true;

                btntic6.Enabled = true;

                btntic7.Enabled = true;

                btntic8.Enabled = true;

                btntic9.Enabled = true;

                btnTic1.Text = "";
                btntic2.Text = "";
                btntic3.Text = "";
                btntic4.Text = "";
                btntic5.Text = "";
                btntic6.Text = "";
                btntic7.Text = "";
                btntic8.Text = "";
                btntic9.Text = "";

                lblPlayerX.Text = "0";
                lblPlayerO.Text = "0";
                btnTic1.BackColor = Color.WhiteSmoke;
                btntic2.BackColor = Color.WhiteSmoke;
                btntic3.BackColor = Color.WhiteSmoke;
                btntic4.BackColor = Color.WhiteSmoke;
                btntic5.BackColor = Color.WhiteSmoke;
                btntic6.BackColor = Color.WhiteSmoke;
                btntic7.BackColor = Color.WhiteSmoke;
                btntic8.BackColor = Color.WhiteSmoke;
                btntic9.BackColor = Color.WhiteSmoke;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


    private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnTic1_Click(object sender, EventArgs e)
        {
            if (checker == false)
            {
                btnTic1.Text = "X";
                checker = true;
            }
            else
            {
                btnTic1.Text = "O";
                checker = false;
            }
            score();
            btnTic1.Enabled = false;
        }

        private void btntic2_Click(object sender, EventArgs e)
        {

            if (checker == false)
            {
                btntic2.Text = "X";
                checker = true;
            }
            else
            {
                btntic2.Text = "O";
                checker = false;
            }
            score();
            btntic2.Enabled = false;
        }

        private void btntic3_Click(object sender, EventArgs e)
        {

            if (checker == false)
            {
                btntic3.Text = "X";
                checker = true;
            }
            else
            {
                btntic3.Text = "O";
                checker = false;
            }
            score();
            btntic3.Enabled = false;
        }

        private void btntic4_Click(object sender, EventArgs e)
        {

            if (checker == false)
            {
                btntic4.Text = "X";
                checker = true;
            }
            else
            {
                btntic4.Text = "O";
                checker = false;
            }
            score();
            btntic4.Enabled = false;
        }

        private void btntic5_Click(object sender, EventArgs e)
        {

            if (checker == false)
            {
                btntic5.Text = "X";
                checker = true;
            }
            else
            {
                btntic5.Text = "O";
                checker = false;
            }
            score();
            btntic5.Enabled = false;
        }

        private void btntic6_Click(object sender, EventArgs e)
        {

            if (checker == false)
            {
                btntic6.Text = "X";
                checker = true;
            }
            else
            {
                btntic6.Text = "O";
                checker = false;
            }
            score();
            btntic6.Enabled = false;
        }

        private void btntic7_Click(object sender, EventArgs e)
        {

            if (checker == false)
            {
                btntic7.Text = "X";
                checker = true;
            }
            else
            {
                btntic7.Text = "O";
                checker = false;
            }
            score();
            btntic7.Enabled = false;
        }

        private void btntic8_Click(object sender, EventArgs e)
        {

            if (checker == false)
            {
                btntic8.Text = "X";
                checker = true;
            }
            else
            {
                btntic8.Text = "O";
                checker = false;
            }
            score();
            btntic8.Enabled = false;
        }

        private void btntic9_Click(object sender, EventArgs e)
        {

            if (checker == false)
            {
                btntic9.Text = "X";
                checker = true;
            }
            else
            {
                btntic9.Text = "O";
                checker = false;
            }
            score();
            btntic9.Enabled = false;
        }

        private void reset_Click(object sender, EventArgs e)
        {
            try
            {
                btnTic1.Enabled = true;

                btntic2.Enabled = true;

                btntic3.Enabled = true;

                btntic4.Enabled = true;

                btntic5.Enabled = true;

                btntic6.Enabled = true;

                btntic7.Enabled = true;

                btntic8.Enabled = true;

                btntic9.Enabled = true;

                btnTic1.Text = "";
                btntic2.Text = "";
                btntic3.Text = "";
                btntic4.Text = "";
                btntic5.Text = "";
                btntic6.Text = "";
                btntic7.Text = "";
                btntic8.Text = "";
                btntic9.Text = "";
                newgame.Enabled = true;

                btnTic1.BackColor = Color.WhiteSmoke;
                btntic2.BackColor = Color.WhiteSmoke;
                btntic3.BackColor = Color.WhiteSmoke;
                btntic4.BackColor = Color.WhiteSmoke;
                btntic5.BackColor = Color.WhiteSmoke;
                btntic6.BackColor = Color.WhiteSmoke;
                btntic7.BackColor = Color.WhiteSmoke;
                btntic8.BackColor = Color.WhiteSmoke;
                btntic9.BackColor = Color.WhiteSmoke;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult iExit;
                iExit = MessageBox.Show("Confirm if you want to exit", "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (iExit == DialogResult.Yes)
                {
                    Application.Exit();
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Tic Tac Toe", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
